(() => {
  const ORG_BADGE_CLASS   = 'serp-rank-badge';
  const LOCAL_BADGE_CLASS = 'serp-local-badge';
  const LABELED_ATTR      = 'data-serp-ranked';
  const STORE_KEY         = 'serpRankState';

  // ─── Persistent state: survives Google page navigations in the same tab ──
  // localStorage is used instead of sessionStorage because some Google SERP
  // navigation variants rebuild the document in a way that can lose the old
  // session state before this content script gets a chance to reuse it.
  function loadState() {
    try { return JSON.parse(localStorage.getItem(STORE_KEY) || 'null'); }
    catch { return null; }
  }
  function saveState(state) {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); }
    catch {}
  }
  function clearState() {
    try { localStorage.removeItem(STORE_KEY); }
    catch {}
  }

  function normalizeQuery(value) {
    return (value || '').trim().replace(/\s+/g, ' ');
  }

  function getCurrentQuery() {
    const params = new URLSearchParams(location.search);
    const fromUrl = params.get('q');
    if (fromUrl) return normalizeQuery(fromUrl);

    const searchBox = document.querySelector('textarea[name="q"], input[name="q"]');
    return normalizeQuery(searchBox?.value || '');
  }

  function getExplicitPageOffset() {
    const params = new URLSearchParams(location.search);

    // Classic Google pagination: ?start=10, ?start=20, ...
    const startParam = Number.parseInt(params.get('start') || '', 10);
    if (Number.isFinite(startParam) && startParam >= 0) return startParam;

    // Some Google variants expose a 1-based page number instead.
    const pageParam = Number.parseInt(params.get('page') || '', 10);
    if (Number.isFinite(pageParam) && pageParam > 1) return (pageParam - 1) * 10;

    return null;
  }

  function getPageKey(currentQuery) {
    const params = new URLSearchParams(location.search);
    const start = params.get('start') || '';
    const page  = params.get('page') || '';
    const udm   = params.get('udm') || '';
    const tbm   = params.get('tbm') || '';
    const filter = params.get('filter') || '';
    return `${currentQuery}::start=${start}::page=${page}::udm=${udm}::tbm=${tbm}::filter=${filter}::path=${location.pathname}`;
  }

  function getPageOffset(currentQuery) {
    const pageKey = getPageKey(currentQuery);
    const state = loadState();

    // Known page always wins. This prevents DOM re-renders from advancing ranks.
    if (state && state.query === currentQuery && state.pageOffsets &&
        Number.isFinite(state.pageOffsets[pageKey])) {
      return state.pageOffsets[pageKey];
    }

    // Direct handoff captured when the user clicked Google's Next control.
    if (state && state.query === currentQuery && Number.isFinite(state.pendingNextOffset)) {
      const offset = state.pendingNextOffset;
      state.pendingNextOffset = null;
      state.pageOffsets = state.pageOffsets || {};
      state.pageOffsets[pageKey] = offset;
      state.currentPageKey = pageKey;
      saveState(state);
      return offset;
    }

    // URL-based pagination is still supported where Google exposes it.
    const explicitOffset = getExplicitPageOffset();
    if (explicitOffset !== null && explicitOffset > 0) return explicitOffset;

    // Last-resort continuation for a genuinely unseen page of the same query.
    if (state && state.query === currentQuery && state.currentPageKey &&
        state.currentPageKey !== pageKey && Number.isFinite(state.lastRank) && state.lastRank > 0) {
      return state.lastRank;
    }

    return 0;
  }

  function captureNextNavigation() {
    document.addEventListener('click', event => {
      const link = event.target.closest('a');
      if (!link) return;

      const text = normalizeQuery(link.innerText || link.getAttribute('aria-label') || '').toLowerCase();
      const id = (link.id || '').toLowerCase();
      const href = link.getAttribute('href') || '';

      // Google has used #pnnext, aria-label="Next", visible "Next", and
      // localized links whose URL contains a larger start/page value.
      const params = (() => {
        try { return new URL(link.href, location.href).searchParams; }
        catch { return null; }
      })();
      const currentParams = new URLSearchParams(location.search);
      const nextStart = Number.parseInt(params?.get('start') || '', 10);
      const curStart = Number.parseInt(currentParams.get('start') || '0', 10);
      const nextPage = Number.parseInt(params?.get('page') || '', 10);
      const curPage = Number.parseInt(currentParams.get('page') || '1', 10);

      const looksLikeNext =
        id === 'pnnext' ||
        text === 'next' ||
        text.includes('next') ||
        (Number.isFinite(nextStart) && nextStart > curStart) ||
        (Number.isFinite(nextPage) && nextPage > curPage);

      if (!looksLikeNext || !href) return;

      const currentQuery = getCurrentQuery();
      const state = loadState();
      if (!state || state.query !== currentQuery || !Number.isFinite(state.lastRank)) return;

      state.pendingNextOffset = state.lastRank;
      saveState(state);
    }, true);
  }
  // ─── Helper: detect Google Ads ────────────────────────────────────────────
  function isAd(el) {
    return !!(
      el.closest('[data-text-ad]') ||
      el.closest('#tads')          ||
      el.closest('#bottomads')     ||
      el.closest('.uEierd')        ||
      el.querySelector('[data-text-ad]')
    );
  }

  // ─── Helper: detect non-organic blocks (PAA, carousels, etc.) ─────────────
  function isNonOrganic(el) {
    return !!(
      el.querySelector('.related-question-pair') ||
      el.classList.contains('g-blk')              ||
      el.querySelector('.F9rcV')                  ||
      el.querySelector('.BVG0Nb')                 ||
      el.querySelector('.kno-rdesc')
    );
  }

  // ─── Inject Organic Result Badges ─────────────────────────────────────────
  function injectOrganicBadges() {
    // Remove stale badges
    document.querySelectorAll(`.${ORG_BADGE_CLASS}`).forEach(b => b.remove());
    document.querySelectorAll(`[${LABELED_ATTR}="organic"]`).forEach(el =>
      el.removeAttribute(LABELED_ATTR)
    );

    const currentQuery = getCurrentQuery();

    // Try selectors in order of stability
    const selectorSets = ['#rso .tF2Cxc', '#rso .g', '#search .g'];
    let candidates = [];
    for (const sel of selectorSets) {
      const found = Array.from(document.querySelectorAll(sel));
      if (found.length >= 2) { candidates = found; break; }
    }

    // Keep only outermost elements (no nested duplicates)
    candidates = candidates.filter(item =>
      !candidates.some(other => other !== item && other.contains(item))
    );

    // Filter to genuine organic results only
    const organicItems = candidates.filter(el => {
      if (isAd(el) || isNonOrganic(el)) return false;
      if (!el.querySelector('h3, [role="heading"]')) return false;
      if (!el.querySelector('a[href^="http"], a[href^="/url"]')) return false;
      return true;
    });

    if (organicItems.length === 0) return;

    const pageOffset = getPageOffset(currentQuery);

    organicItems.forEach((item, index) => {
      const rank = pageOffset + index + 1;

      if (window.getComputedStyle(item).position === 'static') {
        item.style.position = 'relative';
      }

      const badge = document.createElement('div');
      badge.className = ORG_BADGE_CLASS;
      badge.dataset.rank = rank;
      badge.title = `Organic Rank #${rank}`;

      const numEl = document.createElement('span');
      numEl.className = 'serp-rank-number';
      numEl.textContent = rank;
      badge.appendChild(numEl);

      item.appendChild(badge);
      item.setAttribute(LABELED_ATTR, 'organic');
    });

    // ── Save page-aware state so the next page can continue from here ───────
    const lastRank = pageOffset + organicItems.length;
    const pageKey = getPageKey(currentQuery);
    const previousState = loadState();
    const pageOffsets = (previousState && previousState.query === currentQuery && previousState.pageOffsets)
      ? previousState.pageOffsets
      : {};

    pageOffsets[pageKey] = pageOffset;
    saveState({
      query: currentQuery,
      currentPageKey: pageKey,
      pageOffsets,
      lastRank
    });
  }

  // ─── Inject Local Pack Badges ─────────────────────────────────────────────
  function injectLocalBadges() {
    document.querySelectorAll(`.${LOCAL_BADGE_CLASS}`).forEach(b => b.remove());

    const selectorSets = ['.rllt__details', '.VkpGBb', '[data-cid]'];
    let localItems = [];
    for (const sel of selectorSets) {
      const found = Array.from(document.querySelectorAll(sel));
      if (found.length >= 1 && found.length <= 20) {
        const deduped = found.filter(item =>
          !found.some(other => other !== item && other.contains(item))
        );
        if (deduped.length >= 1) { localItems = deduped; break; }
      }
    }

    localItems.forEach((item, index) => {
      const rank = index + 1;
      if (window.getComputedStyle(item).position === 'static') {
        item.style.position = 'relative';
      }

      const badge = document.createElement('div');
      badge.className = LOCAL_BADGE_CLASS;
      badge.dataset.rank = rank;
      badge.title = `Local Pack Rank #${rank}`;

      const numEl    = document.createElement('span');
      numEl.className = 'serp-rank-number';
      numEl.textContent = rank;

      const labelEl    = document.createElement('span');
      labelEl.className = 'serp-badge-label';
      labelEl.textContent = 'Local';

      badge.appendChild(numEl);
      badge.appendChild(labelEl);
      item.appendChild(badge);
    });
  }

  // ─── Run all injectors ────────────────────────────────────────────────────
  function runAll() {
    injectOrganicBadges();
    injectLocalBadges();
  }

  // ─── Debounce ─────────────────────────────────────────────────────────────
  let debounceTimer = null;
  function schedule() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(runAll, 400);
  }

  // ─── MutationObserver — re-number when DOM changes ────────────────────────
  const observer = new MutationObserver(mutations => {
    // Ignore mutations caused by our own badge injection
    const selfChange = mutations.every(m =>
      Array.from(m.addedNodes).concat(Array.from(m.removedNodes)).every(n =>
        n.nodeType === 1 && (
          n.classList?.contains(ORG_BADGE_CLASS) ||
          n.classList?.contains(LOCAL_BADGE_CLASS)
        )
      )
    );
    if (!selfChange) schedule();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // ─── URL change detection — handles "Next page" click ────────────────────
  let lastUrl   = location.href;
  let lastQuery = getCurrentQuery();

  setInterval(() => {
    if (location.href === lastUrl) return;

    const currentQuery = getCurrentQuery();

    // New search query → clear stored state so count resets to 1
    if (currentQuery !== lastQuery) {
      clearState();
      lastQuery = currentQuery;
    }

    lastUrl = location.href;

    // Remove stale badges, then re-inject with new offset
    document.querySelectorAll(`.${ORG_BADGE_CLASS}, .${LOCAL_BADGE_CLASS}`)
            .forEach(b => b.remove());
    document.querySelectorAll(`[${LABELED_ATTR}]`)
            .forEach(el => el.removeAttribute(LABELED_ATTR));

    setTimeout(runAll, 900);
  }, 600);

  captureNextNavigation();

  // ─── Init ─────────────────────────────────────────────────────────────────
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(runAll, 800));
  } else {
    setTimeout(runAll, 800);
  }
})();
